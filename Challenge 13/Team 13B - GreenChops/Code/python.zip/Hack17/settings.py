# Settings

#Imports


API_KEY = "eb2c319ce5a8a672ea1e227d38c9f848"
