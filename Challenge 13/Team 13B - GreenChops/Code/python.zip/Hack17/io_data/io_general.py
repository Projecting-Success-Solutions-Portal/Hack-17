# IO General

# Imports
import pandas as pd

def read_excel():
    df = pd.read_excel()
    return