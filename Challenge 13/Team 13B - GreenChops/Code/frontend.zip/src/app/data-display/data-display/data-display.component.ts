import { Component } from '@angular/core';
import { ClientHttpServiceService } from 'src/app/client-http-service.service';

@Component({
  selector: 'app-data-display',
  templateUrl: './data-display.component.html',
  styleUrls: ['./data-display.component.scss']
})
export class DataDisplayComponent {
  displayedColumns: string[] = ['date', 'office', 'CO2 per person'];
  dataSource: any[] = [];
  constructor(
    private clientHttpService: ClientHttpServiceService
  ){
    clientHttpService.getAll().subscribe({
      next: (data: any[]) => {
        this.dataSource = data;
      }
    })
  }
}
