import { AfterViewInit, Component, ViewChild, ElementRef } from '@angular/core';
import { Chart, registerables } from 'chart.js';
import { ClientHttpServiceService } from 'src/app/client-http-service.service';

@Component({
  selector: 'app-data-visualization',
  templateUrl: './data-visualization.component.html',
  styleUrls: ['./data-visualization.component.scss']
})
export class DataVisualizationComponent implements AfterViewInit {

  @ViewChild('graph')
  public chartRef: ElementRef | null;
  public chart: Chart|null;
  public selectedValue: any
  public officeList: any[];

  constructor(private clientService: ClientHttpServiceService) {
    this.chartRef = null;
    this.chart = null;
    this.selectedValue = 'London'
    Chart.register(...registerables);
    this.officeList = [];
        this.clientService.getAllOfficeList().subscribe({
          next: (datas: any[]) => {
            this.officeList = datas.map((data)=> data.office_id)
            this.selectedValue = this.officeList[0];
          }
        })

  }

  public ngAfterViewInit(): void {
    this.clientService.getCo2Emissions(this.selectedValue).subscribe({
      next: (datas: any[]) => {
        if(this.chart){
          this.chart.destroy();
        } 
        if (this.chartRef) {
          this.chart = new Chart(
            this.chartRef.nativeElement as any,
            {
              type: 'line',
              data: {
                labels: datas.map(row => row.month + ' ' + row.year),
                datasets: [
                  {
                    
                    backgroundColor: 'red',
                    borderColor: 'red',
                    tension: 0.5,
                    label: 'CO2 emissions (kg) by month',
                    data: datas.map(row => row.co2_ppm)
                  },
                  {
                    tension: 0.5,
                    backgroundColor: 'green',
                    borderColor: 'green',
                    label: 'Optimum CO2 emissions (kg) by month',
                    data: datas.map(row => row.optimum_co2_usage)
                  }
                ]
              }
            }
          );
        }

      }
    })
  }

}
