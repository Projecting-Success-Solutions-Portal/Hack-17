import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators, FormArray } from '@angular/forms';
import { MatDatepicker } from '@angular/material/datepicker';
import * as moment from 'moment';
import * as _moment from 'moment';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';
import { ClientHttpServiceService } from './client-http-service.service';
import { MatSnackBar } from '@angular/material/snack-bar';

export const MY_FORMATS = {
  parse: {
    dateInput: 'MM/YYYY',
  },
  display: {
    dateInput: 'MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [
    // `MomentDateAdapter` can be automatically provided by importing `MomentDateModule` in your
    // application's root module. We provide it at the component level here, due to limitations of
    // our example generation script.
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },

    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
})
export class AppComponent {

  public officeConfigurationForm = new FormGroup({
    officeId: new FormControl('', Validators.required),
    officeSize: new FormControl('', Validators.required),
    deskPerFloor: new FormControl('', Validators.required),
    numberOfFloors: new FormControl('', Validators.required),
    occupancyOptions: new FormArray([]),

  });


  title = 'green_ops';
  constructor(
    private clientHttpService: ClientHttpServiceService,
    private _snackBar: MatSnackBar
  ) { }

  public get occupancyOptions(): FormArray {
    const formArray = this.officeConfigurationForm.get('occupancyOptions')
    if(formArray && formArray instanceof FormArray){
      return formArray as FormArray;
    }
    return new FormArray<any>([]);
  }

  public getMaxNumberPeople(): number {
    const control = this.officeConfigurationForm.get('deskPerFloor');
    if (control) {
      return control.value ? parseInt(control.value) : 0;
    }
    return 0;
  }

  public getMaxFloor(): number {
    const control = this.officeConfigurationForm.get('numberOfFloors');
    if (control) {
      return control.value ? parseInt(control.value) : 0;
    }
    return 0;
  }

  public removeOccupancyOptions(index:number):void {
    this.occupancyOptions.removeAt(index);
  }

  public addOccupancyOptions(): void {
    const occupancies = this.officeConfigurationForm.get('occupancyOptions') as FormArray;
    occupancies.push(
      new FormGroup({
        peoplePerFloor: new FormControl('', Validators.required),
        whichFloor: new FormControl('', Validators.required),
        date: new FormControl(moment())
      })
    )
  }


  setMonthAndYear(normalizedMonthAndYear: _moment.Moment, datepicker: MatDatepicker<_moment.Moment>, index:number) {
    const formArray = this.officeConfigurationForm.get('occupancyOptions') as FormArray;
    const ctrlValue = formArray.get(index.toString())?.get('date')?.value!;
    if (moment.isMoment(ctrlValue)) {
      ctrlValue.month(normalizedMonthAndYear.month());
      ctrlValue.year(normalizedMonthAndYear.year());
    }
    formArray.get(index.toString())?.setValue(ctrlValue);
    datepicker.close();
  }

  public submitForm(form: FormGroup) {
    console.log('test');

    const object = form.value;
    this.clientHttpService.createConfig(object).subscribe({
      next: () => {
        console.log('success');

        this._snackBar.open('Configuration saved successfully', 'Close', {
          duration: 3000
        })
      },
      error: (error) => {
        console.log(error);

        this._snackBar.open(error.error, 'Close', {
          duration: 3000
        })
      }
    });
  }
}
