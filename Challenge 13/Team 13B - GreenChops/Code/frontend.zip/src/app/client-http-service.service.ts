import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs'

@Injectable({
  providedIn: 'root'
})
export class ClientHttpServiceService {

  private baseUrl = '/api/'

  constructor(
    private httpClient: HttpClient
  ) { }

  public createConfig(object: any): Observable<string> {
    return this.httpClient.post(
      this.baseUrl + 'addBuildingConfig',
      object, {responseType: 'text'}
    ).pipe(map((returnString) => returnString))
  }

  public getAll(): Observable<any[]> {
    return this.httpClient.get<any[]>(this.baseUrl + 'getOfficeElec').pipe(
      map((values)=>values)
    )
  }
  
  public getByOffice(office: string): Observable<any[]> {
    return this.httpClient.get<any[]>(this.baseUrl + 'getByOfficeElec/'+office).pipe(
      map((values)=>values)
    )
  }
  
  public getCo2Emissions(office: string): Observable<any[]> {
    return this.httpClient.get<any[]>(this.baseUrl + 'getCo2Emissions/'+office).pipe(
      map((values)=>values)
    )
  }
  
  public getAllOfficeList(): Observable<any[]> {
    return this.httpClient.get<any[]>(this.baseUrl + 'getAllOffice/').pipe(
      map((values)=>values)
    )
  }

  
}
