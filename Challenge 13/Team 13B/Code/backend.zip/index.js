const express = require('express')
const bodyParser = require('body-parser')
const app = express()
const port = 3000
const db = require('./queries')

process.on('uncaughtException', function(err) {
    // handle the error safely
    console.log(err)
})
app.use(bodyParser.json())
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
)

app.get('/', (request, response) => {
    response.json({ info: 'Node.js, Express, and Postgres API' })
})

app.listen(port, () => {
console.log(`App running on port ${port}.`)
})

app.post('/addBuildingConfig', db.createBuildingConfig)
app.get('/getOfficeElec', db.getAllOfficeElec)
app.get('/getByOfficeElec/:office', db.getByOfficeElec)
app.get('/getAllOffice', db.getAllOfficeList)
app.get('/getCo2Emissions/:office', db.getCo2EmissionByOffice)