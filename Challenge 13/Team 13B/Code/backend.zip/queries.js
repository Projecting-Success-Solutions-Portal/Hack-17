const Pool = require('pg').Pool
const pool = new Pool({
    user: 'wilkinsonc2',
    host: 'db.bit.io',
    database: 'wilkinsonc2/challenge13',
    password: 'v2_3w8Fx_6xftS8bLJ2nfdWmbdZAc55b',
    port: 5432,
    ssl: true,
    schema: 'public'
})

const getAllOfficeElec = (request, response) => {
 
    pool.query('SELECT * FROM office_elec_and_gas_co2', (error, results) => {
        if (error) {
            response.status(500).send(`Something goes wrong`)
        }
        response.status(201).json(results.rows)
    })   
}

const getAllOfficeList =  (request, response) => {
    pool.query('SELECT * FROM office_configuration', (error, results) => {
        if (error) {
            response.status(500).send(`Something goes wrong`)
        }
        response.status(201).json(results.rows)
    })   
}


const getCo2EmissionByOffice = (request, response) => {
 
    pool.query('SELECT * FROM vw_optimum_co2 WHERE office_id = $1',[request.params.office], (error, results) => {
        if (error) {
            response.status(500).send(`Something goes wrong`)
        }
        response.status(201).json(results.rows)
    })   
}

const getByOfficeElec = (request, response) => {
 
    pool.query('SELECT * FROM office_elec_and_gas_co2 WHERE office_id = $1',[request.params.office], (error, results) => {
        if (error) {
            response.status(500).send(`Something goes wrong`)
        }
        response.status(201).json(results.rows)
    })   
}

const createBuildingConfig = (request, response) => {
    const { officeId , deskPerFloor, numberOfFloors, officeSize, occupancyOptions} = request.body

    
    pool.query('INSERT INTO office_configuration (office_id, no_of_floors, total_desks, "office_space-sqm") VALUES ($4 ,$1, $2, $3) RETURNING *', [numberOfFloors, deskPerFloor, officeSize, officeId], (error, results) => {
        if (error) {
            response.status(500).send(`Something goes wrong in office configuration`)
        }
        // console.log(results);
        
console.log(occupancyOptions);
occupancyOptions.forEach((occupancyOption)=>{
    const fullDate = new Date(occupancyOption.date)

    const shortName = fullDate.toLocaleString('en-GB', { month: 'short' });
    
    pool.query('INSERT INTO occupancy_options (year, month, office_id, which_floor, people_per_floor) VALUES ($1, $2, $3, $4, $5) RETURNING *', [fullDate.getFullYear(), shortName, results.rows[0].office_id, occupancyOption.whichFloor, occupancyOption.peoplePerFloor], (error, results) => {
        if (error) {
            response.status(500).send(`Something goes wrong`)
        }
        response.status(201).send(`Configuration added`)
    })
})
    })
}


module.exports = {
    createBuildingConfig,
    getAllOfficeElec,
    getByOfficeElec,
    getAllOfficeList,
    getCo2EmissionByOffice
}